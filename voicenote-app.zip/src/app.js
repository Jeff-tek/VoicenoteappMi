import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Mic, MicOff, Play, Pause, Trash2, Calendar, CheckSquare, Lightbulb, Clock, Settings } from 'lucide-react';

const VoiceNote = () => {
  const [isRecording, setIsRecording] = useState(false);
  const [recordings, setRecordings] = useState([]);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [playingId, setPlayingId] = useState(null);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [microphonePermission, setMicrophonePermission] = useState('unknown');
  const [error, setError] = useState('');
  
  const mediaRecorderRef = useRef(null);
  const audioChunksRef = useRef([]);
  const streamRef = useRef(null);
  const audioRef = useRef(null);

  // Sample processed recordings with AI-extracted content
  const sampleRecordings = [
    {
      id: 1,
      timestamp: new Date(Date.now() - 3600000),
      duration: 45,
      transcript: "I need to call Sarah about the marketing meeting tomorrow at 2pm. Also remind me to prepare the quarterly budget report by Friday. Oh and I had this great idea for improving our customer onboarding process - we should create interactive video tutorials instead of just PDFs.",
      tasks: [
        { id: 1, text: "Call Sarah about marketing meeting", due: "Tomorrow 2:00 PM", priority: "high" },
        { id: 2, text: "Prepare quarterly budget report", due: "Friday", priority: "medium" }
      ],
      ideas: [
        { id: 1, text: "Interactive video tutorials for customer onboarding", category: "product improvement" }
      ],
      events: [
        { id: 1, text: "Marketing meeting with Sarah", time: "Tomorrow 2:00 PM" }
      ]
    },
    {
      id: 2,
      timestamp: new Date(Date.now() - 7200000),
      duration: 32,
      transcript: "The client presentation went really well today. They loved the new dashboard design. I should follow up with them by Wednesday to get their final feedback. Also need to update the project timeline and let the development team know about the changes they requested.",
      tasks: [
        { id: 3, text: "Follow up with client for final feedback", due: "Wednesday", priority: "high" },
        { id: 4, text: "Update project timeline", due: "This week", priority: "medium" },
        { id: 5, text: "Inform dev team about client changes", due: "ASAP", priority: "high" }
      ],
      ideas: [],
      events: []
    },
    {
      id: 3,
      timestamp: new Date(Date.now() - 10800000),
      duration: 28,
      transcript: "Had coffee with John from the startup accelerator. He mentioned they're looking for mentors for their next cohort. Might be interesting to apply. The program runs from March to June. I should research their portfolio companies and see if it aligns with my expertise.",
      tasks: [
        { id: 6, text: "Research accelerator portfolio companies", due: "Next week", priority: "low" },
        { id: 7, text: "Apply for mentor position", due: "End of month", priority: "medium" }
      ],
      ideas: [
        { id: 2, text: "Mentoring at startup accelerator", category: "career opportunity" }
      ],
      events: []
    }
  ];

  // Check microphone permission on mount
  useEffect(() => {
    const checkMicrophonePermission = async () => {
      try {
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
          setMicrophonePermission('unsupported');
          return;
        }

        const permission = await navigator.permissions.query({ name: 'microphone' });
        setMicrophonePermission(permission.state);
        
        permission.onchange = () => {
          setMicrophonePermission(permission.state);
        };
      } catch (error) {
        console.log('Permission API not supported, will check on first recording attempt');
        setMicrophonePermission('unknown');
      }
    };

    checkMicrophonePermission();
  }, []);

  useEffect(() => {
    if (recordings.length === 0) {
      setRecordings(sampleRecordings);
    }

    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, [recordings.length]);

  // Cleanup function
  const cleanupRecording = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (mediaRecorderRef.current) {
      mediaRecorderRef.current = null;
    }
    setIsRecording(false);
  }, []);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      cleanupRecording();
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
    };
  }, [cleanupRecording]);

  const startRecording = async () => {
    try {
      setError('');
      
      // Check if MediaRecorder is supported
      if (!window.MediaRecorder) {
        throw new Error('MediaRecorder is not supported in this browser');
      }

      // Check if getUserMedia is supported
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error('Microphone access is not supported in this browser');
      }

      const stream = await navigator.mediaDevices.getUserMedia({ 
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          sampleRate: 44100
        } 
      });
      
      streamRef.current = stream;
      setMicrophonePermission('granted');
      
      // Check if MediaRecorder supports the stream
      if (!MediaRecorder.isTypeSupported('audio/webm')) {
        console.warn('audio/webm not supported, falling back to default');
      }

      const options = MediaRecorder.isTypeSupported('audio/webm') 
        ? { mimeType: 'audio/webm' }
        : {};

      mediaRecorderRef.current = new MediaRecorder(stream, options);
      audioChunksRef.current = [];

      mediaRecorderRef.current.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorderRef.current.onstop = () => {
        try {
          const mimeType = mediaRecorderRef.current?.mimeType || 'audio/webm';
          const audioBlob = new Blob(audioChunksRef.current, { type: mimeType });
          const audioUrl = URL.createObjectURL(audioBlob);
          
          // Simulate AI processing with random realistic content
          const mockTranscripts = [
            "I need to schedule a team meeting for next Tuesday to discuss the project roadmap. Also remind me to review the budget proposal and send feedback to finance by Thursday.",
            "Had a great brainstorming session today. We came up with three new feature ideas for the mobile app. I should document these and share with the product team.",
            "Client called about the delivery timeline. They're flexible with the deadline but want weekly updates. Need to set up recurring check-ins.",
            "Remember to prepare for the presentation next week. Include the latest analytics data and customer feedback summary."
          ];

          const transcript = mockTranscripts[Math.floor(Math.random() * mockTranscripts.length)];
          
          const newRecording = {
            id: Date.now(),
            timestamp: new Date(),
            duration: Math.floor(Math.random() * 60) + 15,
            audioUrl,
            transcript,
            tasks: extractTasks(transcript),
            ideas: extractIdeas(transcript),
            events: extractEvents(transcript)
          };

          setRecordings(prev => [newRecording, ...prev]);
        } catch (error) {
          console.error('Error processing recording:', error);
          setError('Error processing recording');
        } finally {
          cleanupRecording();
        }
      };

      mediaRecorderRef.current.onerror = (event) => {
        console.error('MediaRecorder error:', event.error);
        setError('Recording error occurred');
        cleanupRecording();
      };

      mediaRecorderRef.current.start(1000); // Collect data every second
      setIsRecording(true);
    } catch (error) {
      console.error('Error starting recording:', error);
      let errorMessage = 'Could not access microphone. ';
      
      if (error.name === 'NotAllowedError') {
        errorMessage += 'Please allow microphone permissions and try again.';
        setMicrophonePermission('denied');
      } else if (error.name === 'NotFoundError') {
        errorMessage += 'No microphone found on this device.';
      } else if (error.name === 'NotSupportedError') {
        errorMessage += 'Your browser does not support audio recording.';
      } else {
        errorMessage += error.message || 'Please check your browser settings.';
      }
      
      setError(errorMessage);
      cleanupRecording();
    }
  };

  const stopRecording = () => {
    try {
      if (mediaRecorderRef.current && isRecording) {
        if (mediaRecorderRef.current.state !== 'inactive') {
          mediaRecorderRef.current.stop();
        }
      }
    } catch (error) {
      console.error('Error stopping recording:', error);
      cleanupRecording();
    }
  };

  const extractTasks = (transcript) => {
    const taskKeywords = ['remind me', 'need to', 'should', 'have to'];
    const tasks = [];
    
    if (taskKeywords.some(keyword => transcript.toLowerCase().includes(keyword))) {
      const sampleTasks = [
        { id: Date.now() + 1, text: "Schedule team meeting", due: "Next Tuesday", priority: "medium" },
        { id: Date.now() + 2, text: "Review budget proposal", due: "Thursday", priority: "high" },
        { id: Date.now() + 3, text: "Prepare presentation materials", due: "Next week", priority: "medium" }
      ];
      return sampleTasks.slice(0, Math.floor(Math.random() * 3) + 1);
    }
    return tasks;
  };

  const extractIdeas = (transcript) => {
    const ideaKeywords = ['idea', 'brainstorm', 'feature', 'improve'];
    const ideas = [];
    
    if (ideaKeywords.some(keyword => transcript.toLowerCase().includes(keyword))) {
      const sampleIdeas = [
        { id: Date.now() + 1, text: "Mobile app feature enhancement", category: "product" },
        { id: Date.now() + 2, text: "Customer feedback integration", category: "process improvement" }
      ];
      return sampleIdeas.slice(0, Math.floor(Math.random() * 2) + 1);
    }
    return ideas;
  };

  const extractEvents = (transcript) => {
    const eventKeywords = ['meeting', 'call', 'presentation', 'schedule'];
    const events = [];
    
    if (eventKeywords.some(keyword => transcript.toLowerCase().includes(keyword))) {
      const sampleEvents = [
        { id: Date.now() + 1, text: "Team meeting", time: "Next Tuesday 10:00 AM" }
      ];
      return sampleEvents.slice(0, 1);
    }
    return events;
  };

  const playAudio = (id, audioUrl) => {
    try {
      // Stop any currently playing audio
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }

      if (playingId === id) {
        setPlayingId(null);
        return;
      }
      
      setPlayingId(id);
      if (audioUrl) {
        audioRef.current = new Audio(audioUrl);
        audioRef.current.play().catch(error => {
          console.error('Error playing audio:', error);
          setPlayingId(null);
        });
        audioRef.current.onended = () => {
          setPlayingId(null);
          audioRef.current = null;
        };
        audioRef.current.onerror = () => {
          setPlayingId(null);
          audioRef.current = null;
        };
      } else {
        // Simulate playback for demo recordings
        setTimeout(() => setPlayingId(null), 2000);
      }
    } catch (error) {
      console.error('Error playing audio:', error);
      setPlayingId(null);
    }
  };

  const deleteRecording = (id) => {
    // Clean up audio URL to prevent memory leaks
    const recording = recordings.find(r => r.id === id);
    if (recording && recording.audioUrl) {
      URL.revokeObjectURL(recording.audioUrl);
    }
    
    setRecordings(prev => prev.filter(r => r.id !== id));
    
    // Stop playing if this recording is currently playing
    if (playingId === id) {
      setPlayingId(null);
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
    }
  };

  const formatTime = (date) => {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const formatDate = (date) => {
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    
    if (date.toDateString() === today.toDateString()) {
      return 'Today';
    } else if (date.toDateString() === yesterday.toDateString()) {
      return 'Yesterday';
    } else {
      return date.toLocaleDateString();
    }
  };

  const allTasks = recordings.flatMap(r => r.tasks);
  const allIdeas = recordings.flatMap(r => r.ideas);
  const allEvents = recordings.flatMap(r => r.events);

  const DashboardView = () => (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-blue-500 to-purple-600 text-white p-6 rounded-2xl">
        <h2 className="text-2xl font-bold mb-2">Good {currentTime.getHours() < 12 ? 'Morning' : currentTime.getHours() < 18 ? 'Afternoon' : 'Evening'}!</h2>
        <p className="opacity-90">You have {allTasks.length} tasks and {allIdeas.length} ideas from your voice notes</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-xl border border-gray-200">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold text-gray-800">Recent Tasks</h3>
            <CheckSquare className="w-5 h-5 text-blue-500" />
          </div>
          <div className="space-y-2">
            {allTasks.slice(0, 3).map(task => (
              <div key={task.id} className="flex items-start space-x-2">
                <div className={`w-2 h-2 rounded-full mt-2 ${task.priority === 'high' ? 'bg-red-400' : task.priority === 'medium' ? 'bg-yellow-400' : 'bg-green-400'}`} />
                <div className="flex-1">
                  <p className="text-sm text-gray-800">{task.text}</p>
                  <p className="text-xs text-gray-500">{task.due}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-gray-200">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold text-gray-800">Ideas</h3>
            <Lightbulb className="w-5 h-5 text-yellow-500" />
          </div>
          <div className="space-y-2">
            {allIdeas.slice(0, 3).map(idea => (
              <div key={idea.id} className="p-2 bg-yellow-50 rounded-lg">
                <p className="text-sm text-gray-800">{idea.text}</p>
                <p className="text-xs text-yellow-600 capitalize">{idea.category}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-gray-200">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold text-gray-800">Upcoming</h3>
            <Calendar className="w-5 h-5 text-green-500" />
          </div>
          <div className="space-y-2">
            {allEvents.slice(0, 3).map(event => (
              <div key={event.id} className="p-2 bg-green-50 rounded-lg">
                <p className="text-sm text-gray-800">{event.text}</p>
                <p className="text-xs text-green-600">{event.time}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );

  const RecordingsView = () => (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-gray-800">Voice Recordings</h2>
        <span className="text-sm text-gray-500">{recordings.length} recordings</span>
      </div>

      {recordings.map(recording => (
        <div key={recording.id} className="bg-white p-4 rounded-xl border border-gray-200 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <button
                onClick={() => playAudio(recording.id, recording.audioUrl)}
                className="p-2 bg-blue-100 rounded-full hover:bg-blue-200 transition-colors"
              >
                {playingId === recording.id ? 
                  <Pause className="w-4 h-4 text-blue-600" /> : 
                  <Play className="w-4 h-4 text-blue-600" />
                }
              </button>
              <div>
                <p className="font-medium text-gray-800">{formatDate(recording.timestamp)}</p>
                <p className="text-sm text-gray-500">{formatTime(recording.timestamp)} • {recording.duration}s</p>
              </div>
            </div>
            <button
              onClick={() => deleteRecording(recording.id)}
              className="p-2 text-gray-400 hover:text-red-500 transition-colors"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>

          <div className="bg-gray-50 p-3 rounded-lg">
            <p className="text-sm text-gray-700 leading-relaxed">{recording.transcript}</p>
          </div>

          {(recording.tasks.length > 0 || recording.ideas.length > 0 || recording.events.length > 0) && (
            <div className="space-y-3">
              {recording.tasks.length > 0 && (
                <div>
                  <h4 className="text-sm font-semibold text-gray-700 mb-2 flex items-center">
                    <CheckSquare className="w-4 h-4 mr-1" /> Tasks Extracted
                  </h4>
                  <div className="space-y-1">
                    {recording.tasks.map(task => (
                      <div key={task.id} className="flex items-center space-x-2 text-sm">
                        <div className={`w-2 h-2 rounded-full ${task.priority === 'high' ? 'bg-red-400' : task.priority === 'medium' ? 'bg-yellow-400' : 'bg-green-400'}`} />
                        <span className="text-gray-800">{task.text}</span>
                        <span className="text-gray-500">• {task.due}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {recording.ideas.length > 0 && (
                <div>
                  <h4 className="text-sm font-semibold text-gray-700 mb-2 flex items-center">
                    <Lightbulb className="w-4 h-4 mr-1" /> Ideas Captured
                  </h4>
                  <div className="space-y-1">
                    {recording.ideas.map(idea => (
                      <div key={idea.id} className="text-sm bg-yellow-50 p-2 rounded">
                        <span className="text-gray-800">{idea.text}</span>
                        <span className="text-yellow-600 ml-2 capitalize">({idea.category})</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {recording.events.length > 0 && (
                <div>
                  <h4 className="text-sm font-semibold text-gray-700 mb-2 flex items-center">
                    <Calendar className="w-4 h-4 mr-1" /> Events Detected
                  </h4>
                  <div className="space-y-1">
                    {recording.events.map(event => (
                      <div key={event.id} className="text-sm bg-green-50 p-2 rounded">
                        <span className="text-gray-800">{event.text}</span>
                        <span className="text-green-600 ml-2">{event.time}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      ))}
    </div>
  );

  const TasksView = () => (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-gray-800">All Tasks</h2>
        <span className="text-sm text-gray-500">{allTasks.length} tasks</span>
      </div>

      <div className="space-y-3">
        {allTasks.map(task => (
          <div key={task.id} className="bg-white p-4 rounded-xl border border-gray-200">
            <div className="flex items-start space-x-3">
              <div className={`w-3 h-3 rounded-full mt-1 ${task.priority === 'high' ? 'bg-red-400' : task.priority === 'medium' ? 'bg-yellow-400' : 'bg-green-400'}`} />
              <div className="flex-1">
                <p className="font-medium text-gray-800">{task.text}</p>
                <div className="flex items-center space-x-3 mt-1">
                  <span className="text-sm text-gray-500">{task.due}</span>
                  <span className={`text-xs px-2 py-1 rounded-full ${task.priority === 'high' ? 'bg-red-100 text-red-700' : task.priority === 'medium' ? 'bg-yellow-100 text-yellow-700' : 'bg-green-100 text-green-700'}`}>
                    {task.priority} priority
                  </span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-4 py-4">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
              <Mic className="w-4 h-4 text-white" />
            </div>
            <h1 className="text-xl font-bold text-gray-800">VoiceNote</h1>
          </div>
          <div className="flex items-center space-x-2">
            <span className="text-sm text-gray-500">{formatTime(currentTime)}</span>
            <Settings className="w-5 h-5 text-gray-400" />
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-6">
        {/* Recording Controls */}
        <div className="bg-white p-6 rounded-2xl border border-gray-200 mb-6">
          {error && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg">
              <p className="text-sm text-red-700">{error}</p>
            </div>
          )}
          
          {microphonePermission === 'denied' && (
            <div className="mb-4 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
              <p className="text-sm text-yellow-700">
                Microphone access is blocked. Please enable it in your browser settings and refresh the page.
              </p>
            </div>
          )}

          {microphonePermission === 'unsupported' && (
            <div className="mb-4 p-3 bg-gray-50 border border-gray-200 rounded-lg">
              <p className="text-sm text-gray-700">
                Audio recording is not supported in this browser. Please try Chrome, Firefox, or Safari.
              </p>
            </div>
          )}

          <div className="flex items-center justify-center space-x-4">
            <button
              onClick={isRecording ? stopRecording : startRecording}
              disabled={microphonePermission === 'denied' || microphonePermission === 'unsupported'}
              className={`w-16 h-16 rounded-full flex items-center justify-center transition-all duration-200 ${
                microphonePermission === 'denied' || microphonePermission === 'unsupported'
                  ? 'bg-gray-300 cursor-not-allowed'
                  : isRecording 
                    ? 'bg-red-500 hover:bg-red-600 animate-pulse' 
                    : 'bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700'
              }`}
            >
              {isRecording ? 
                <MicOff className="w-6 h-6 text-white" /> : 
                <Mic className="w-6 h-6 text-white" />
              }
            </button>
            <div className="text-center">
              <p className="font-semibold text-gray-800">
                {isRecording ? 'Recording...' : 'Tap to record'}
              </p>
              <p className="text-sm text-gray-500">
                {isRecording ? 'Speak your thoughts naturally' : 'Transform your voice into organized tasks'}
              </p>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex space-x-1 bg-gray-100 p-1 rounded-xl mb-6">
          {[
            { id: 'dashboard', label: 'Dashboard', icon: Calendar },
            { id: 'recordings', label: 'Recordings', icon: Mic },
            { id: 'tasks', label: 'Tasks', icon: CheckSquare }
          ].map(tab => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex-1 flex items-center justify-center space-x-2 py-2 px-4 rounded-lg transition-colors ${
                  activeTab === tab.id
                    ? 'bg-white text-blue-600 shadow-sm'
                    : 'text-gray-600 hover:text-gray-800'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span className="font-medium">{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Content Views */}
        {activeTab === 'dashboard' && <DashboardView />}
        {activeTab === 'recordings' && <RecordingsView />}
        {activeTab === 'tasks' && <TasksView />}
      </div>
    </div>
  );
};

export default VoiceNote;